
<?php
$booking = true;
?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="page-header">
        <div class="row">
            <div class="col-sm-12">
                <h3 class="page-title">List of Hotels</h3>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('index.html')); ?>">Dashboard</a></li>
                    
                    <li class="breadcrumb-item active">Hotels</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /Page Header -->

    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="datatable table table-hover table-center mb-0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Travel purpose</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="<?php echo e(url('profile.html')); ?>" class="avatar avatar-sm mr-2"><img
                                                        class="avatar-img rounded-circle"
                                                        src="<?php echo e(asset('/admin/assets/img/profiles/avatar-08.jpg')); ?>"
                                                        alt="User Image"></a>
                                                <a href="<?php echo e(url('profile.html')); ?>"><?php echo e($booking->firstname); ?> <?php echo e($booking->lastname); ?></a>
                                            </h2>
                                        </td>
                                        <td><?php echo e($booking->email); ?></td>

                                        <td><?php echo e($booking->phone); ?></td>

                                        <td><?php echo e($booking->travel_purpose); ?></td>

                                        <td>
                                            <div class="status-toggle d-flex justify-content-center">
                                                <input type="checkbox" id="status_1" class="check" checked>
                                                <label for="status_1" class="checktoggle">checkbox</label>
                                            </div>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables/datatables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\obocas\resources\views/admin/bookings.blade.php ENDPATH**/ ?>