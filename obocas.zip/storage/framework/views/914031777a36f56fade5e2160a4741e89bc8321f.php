<!-- Header -->
<div class="guest-header">
            <header class="_37rfPfc52EXATe8n6xoWgd">
                <nav class="_2HVwqciw9DfOQFLWl2-a_I container">
                    <div class="_1pRpeQP2z_3ktRb8Urjtv6">
                        <div class="daGIlH2FHgTbq-rtCh3t">
                            <a href="/">
                                <img src="<?php echo e(asset('registration/assets/images/logo.png')); ?>" alt="">
                            </a>
                        </div>
                    </div>
                </nav>
            </header>
        </div>
        <!-- /Header -->
<?php /**PATH I:\Projects\Laravel\obocas\resources\views/public/create-property-header.blade.php ENDPATH**/ ?>