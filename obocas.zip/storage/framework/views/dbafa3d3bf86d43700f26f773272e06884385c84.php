<!DOCTYPE html>
<html lang="en">

<head>
    <!--====== Required meta tags =======-->
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=on" />

    <!--====== Title =======-->
    <title>Booking Index</title>

    <!-- <link rel="stylesheet" href="<?php echo e(asset('registration/assets/css/bootstrap.min.css')); ?>"> -->
    <?php echo $__env->yieldContent('css'); ?>

    <!-- <link rel="stylesheet" href="<?php echo e(asset('registration/assets/css/index.css')); ?>" /> -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('registration/assets/css/about.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('registration/assets/css/create-room.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('registration/assets/css/photos.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('registration/assets/css/policies.css')); ?>" /> -->


    

</head>
<body>
    <div id="root" class="bui-u-text-left bui_font_body">
        <?php echo $__env->make('public.create-property-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <!-- <?php echo $__env->make('public.create-property-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
    </div>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH I:\Projects\Laravel\obocas\resources\views/public/create-property-layout.blade.php ENDPATH**/ ?>