<div class="row join_thankyou__footer" id="footer_wrapper">
                    <footer>
                        <ul class="list-unstyled list-inline clearfix">

                            <li id="footer-booking" class="pull-right" data-ga-track="sb_footer_bookingindex_click">
                                © Copyright <a href="https://booking.com/?lang=en" target="_blank">Booking.com</a> 2022
                            </li>

                            <li class="pull-left" id="footer-about-us" data-ga-track="sb_footer_about_us_click">
                                <a href="https://booking.com/content/about.html?lang=en" target="_blank">
                                    About Us
                                </a>
                            </li>
                            <li class="pull-left" id="footer-privacy" data-ga-track="sb_footer_privacy_click">
                                <a href="https://admin.booking.com/hotel/hoteladmin/privacy.html?lang=en"
                                    target="_blank">
                                    Privacy and Cookie Statement
                                </a>
                            </li>
                            <li id="footer-faq" class="pull-left">
                                <a href="/faq.html?aid=304142&amp;token=f63dae3dd0bc4bafea1227e4b9fa86c81d271736&amp;label=gen173nr-1FCAEoggI46AdIM1gEaBSIAQGYAQm4ARjIAQzYAQHoAQH4AQuIAgGoAgS4AvDzxpIGwAIB0gIkNjFhZjc0YTMtMzlmZi00NGZiLThjNjItMTRmMTc3Y2ZhZWJj2AIG4AIB"
                                    data-ga-track="sb_footer_bookingindex_faq_click" target="_blank">FAQs</a>
                            </li>


                        </ul>
                    </footer>
                </div><?php /**PATH I:\Projects\Laravel\obocas\resources\views/public/create-property-footer.blade.php ENDPATH**/ ?>